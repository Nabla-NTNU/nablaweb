Name: Free Swirl Floral Vector 
Copyright: Web Design Hot! 
Author: xeme 
Homepage: http://www.webdesignhot.com/ 
License: Creative Commons Attribution 3.0 
File Type: EPS 
This image is a vector illustration and can be scaled to any size without loss of resolution. This image will download as a .eps or ai file. You will need a vector editor to use this file (such as Adobe Illustrator). 